#ifndef COMMIT_H
#define COMMIT_H

int clurg_commit(const char *message);

#endif /* COMMIT_H */
