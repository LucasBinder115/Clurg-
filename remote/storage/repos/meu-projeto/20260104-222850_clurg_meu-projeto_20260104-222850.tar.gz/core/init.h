#ifndef CLURG_INIT_H
#define CLURG_INIT_H

int clurg_init(void);

#endif
