#ifndef PUSH_H
#define PUSH_H

int clurg_push(const char *arg1, const char *arg2, const char *arg3);

#endif