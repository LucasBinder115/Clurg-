#ifndef CLONE_H
#define CLONE_H

int clurg_clone(const char *project_name, const char *remote_url);

#endif