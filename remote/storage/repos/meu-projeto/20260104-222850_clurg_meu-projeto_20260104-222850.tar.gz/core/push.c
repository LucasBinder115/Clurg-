#include <limits.h>
#include <linux/limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define MAX_PATH PATH_MAX

static int prepare_snapshot(const char *project_name, char *snapshot_path,
                            size_t size) {
  char timestamp[64];
  time_t now = time(NULL);
  struct tm *t = localtime(&now);
  strftime(timestamp, sizeof(timestamp), "%Y%m%d-%H%M%S", t);

  // Caminho temporário para o snapshot
  snprintf(snapshot_path, size, "/tmp/clurg_%s_%s.tar.gz", project_name,
           timestamp);

  char cmd[2048];
  /* tar --exclude=.clurg -czf <path> . */
  snprintf(cmd, sizeof(cmd), "tar --exclude=.clurg -czf \"%s\" . 2>/dev/null",
           snapshot_path);

  printf("📦 Gerando snapshot do projeto '%s'...\n", project_name);
  int ret = system(cmd);
  if (ret != 0) {
    fprintf(stderr, "erro: falha ao criar tar.gz (ret=%d)\n", ret);
    return 1;
  }
  return 0;
}

static int store_local_copy(const char *snapshot_path) {
  char local_dir[] = ".clurg/snapshots";
  char cmd[2048];

  printf("💾 Salvando backup local em %s/...\n", local_dir);

  // Criar diretório e copiar
  snprintf(cmd, sizeof(cmd), "mkdir -p %s && cp \"%s\" %s/", local_dir,
           snapshot_path, local_dir);

  int ret = system(cmd);
  if (ret != 0) {
    fprintf(stderr, "aviso: falha ao salvar cópia local (ret=%d)\n", ret);
    // Não retornamos erro fatal aqui, pois o remote ainda pode funcionar
  }
  return 0;
}

static int send_remote(const char *project_name, const char *snapshot_path,
                       const char *remote_url, const char *notes) {
  char cmd[4096];

  printf("🌐 Enviando para o Clurg Remote: %s...\n", remote_url);

  // Verificar se o arquivo existe e não está vazio
  FILE *check_fp = fopen(snapshot_path, "rb");
  if (!check_fp) {
    fprintf(stderr, "erro: snapshot não encontrado em %s\n", snapshot_path);
    return 1;
  }
  fseek(check_fp, 0, SEEK_END);
  long size = ftell(check_fp);
  fclose(check_fp);

  if (size <= 0) {
    fprintf(stderr, "erro: snapshot gerado está vazio\n");
    return 1;
  }

  /* curl -s -f -X POST -F "file=@path" -F "project=name" -F "notes=..." url */
  if (snprintf(cmd, sizeof(cmd),
               "curl -s -f -X POST -F \"file=@%s\" -F \"project=%s\" -F \"notes=%s\" \"%s\"",
               snapshot_path, project_name, notes ? notes : "", remote_url) >= (int)sizeof(cmd)) {
    fprintf(stderr, "erro: comando curl muito longo\n");
    return 1;
  }

  int ret = system(cmd);
  if (ret != 0) {
    fprintf(stderr,
            "erro: falha ao enviar para o remoto (ret=%d). Verifique a URL.\n",
            ret);
    return 1;
  }
  return 0;
}

int clurg_push(const char *arg1, const char *arg2, const char *arg3) {
  char project_name[256] = "default";
  char remote_url[1024];
  const char *notes = arg3;
  char snapshot_path[MAX_PATH];

  // Parse arguments
  if (!arg1) {
    fprintf(stderr, "erro: argumentos insuficientes\n");
    fprintf(stderr, "Uso: clurg push <project_name> <remote_url> [notes]\n");
    fprintf(stderr, "Ou: clurg push <remote_url> [notes] (usa 'default' como projeto)\n");
    return 1;
  }

  if (arg2 && (strncmp(arg2, "http", 4) == 0)) {
    // arg1: project, arg2: url, arg3: notes
    strncpy(project_name, arg1, sizeof(project_name) - 1);
    project_name[sizeof(project_name) - 1] = '\0';
    strncpy(remote_url, arg2, sizeof(remote_url) - 1);
    remote_url[sizeof(remote_url) - 1] = '\0';
  } else {
    // arg1: url, arg2: notes
    strncpy(remote_url, arg1, sizeof(remote_url) - 1);
    remote_url[sizeof(remote_url) - 1] = '\0';
    notes = arg2;
  }

  // 1. Prepare Snapshot
  if (prepare_snapshot(project_name, snapshot_path, sizeof(snapshot_path)) != 0) {
    return 1;
  }

  // 2. Store Local Copy
  store_local_copy(snapshot_path);

  // 3. Send Remote
  int ret = send_remote(project_name, snapshot_path, remote_url, notes);

  // Cleanup temp file
  remove(snapshot_path);

  if (ret == 0) {
    printf("✅ Push executado com sucesso!\n");
  } else {
    printf("⚠️  Push concluído com erros no remoto, mas o snapshot local foi salvo.\n");
  }

  return ret;
}