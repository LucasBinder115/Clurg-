# app/server.py - Versão notebook
import os
import sqlite3
import hashlib
from datetime import datetime
from flask import Flask, request, jsonify, send_file, Response
from werkzeug.utils import secure_filename
import toml

app = Flask(__name__)

# Carrega configuração
config = toml.load('config.toml')
STORAGE_PATH = config['storage']['path']
DB_PATH = config['database']['path']
ALLOWED_EXTENSIONS = {'tar.gz'}

# Banco de dados
def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute('''
        CREATE TABLE IF NOT EXISTS snapshots (
            id TEXT PRIMARY KEY,
            project_name TEXT,
            filename TEXT,
            hash TEXT,
            size INTEGER,
            created_at TIMESTAMP,
            notes TEXT
        )
    ''')
    # Add notes column if not exists (for migration)
    try:
        conn.execute('ALTER TABLE snapshots ADD COLUMN notes TEXT DEFAULT ""')
        conn.commit()
    except sqlite3.OperationalError:
        pass  # Column already exists
    conn.close()

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'online', 'storage': STORAGE_PATH})

@app.route('/snapshot', methods=['POST'])
def upload_snapshot():
    """Recebe snapshot .tar.gz"""
    if 'file' not in request.files:
        return jsonify({'error': 'Nenhum arquivo'}), 400
    
    file = request.files['file']
    if file.filename == '' or not allowed_file(file.filename):
        return jsonify({'error': 'Arquivo inválido'}), 400
    
    # Gera ID único
    file_id = hashlib.md5(f"{datetime.now()}{file.filename}".encode()).hexdigest()[:12]
    final_filename = f"{file_id}.tar.gz"
    project = request.form.get('project', 'unknown')
    project_dir = os.path.join(STORAGE_PATH, 'repos', project)
    os.makedirs(project_dir, exist_ok=True)
    filepath = os.path.join(project_dir, final_filename)

    # Salva arquivo
    file.save(filepath)
    
    # Salva metadados
    file_size = os.path.getsize(filepath)
    file_hash = hashlib.md5(open(filepath, 'rb').read()).hexdigest()
    
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        'INSERT INTO snapshots VALUES (?, ?, ?, ?, ?, ?, ?)',
        (file_id, request.form.get('project'), final_filename,
         file_hash, file_size, datetime.now(), request.form.get('notes', ''))
    )
    conn.commit()
    conn.close()
    
    return jsonify({
        'id': file_id,
        'filename': final_filename,
        'url': f"/snapshot/{file_id}"
    })

@app.route('/snapshots', methods=['GET'])
def list_snapshots():
    """Lista todos os snapshots"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.execute('SELECT id, project_name, filename, size, created_at FROM snapshots ORDER BY created_at DESC')
    snapshots = [
        {
            'id': row[0],
            'project': row[1],
            'filename': row[2],
            'size': row[3],
            'created_at': row[4]
        }
        for row in cursor.fetchall()
    ]
    conn.close()
    return jsonify({'snapshots': snapshots})

@app.route('/snapshot/<snapshot_id>', methods=['GET'])
def download_snapshot(snapshot_id):
    """Baixa snapshot pelo ID"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.execute('SELECT filename, project_name FROM snapshots WHERE id = ?', (snapshot_id,))
    result = cursor.fetchone()
    conn.close()

    if not result:
        return jsonify({'error': 'Snapshot não encontrado'}), 404

    filename, project_name = result
    filepath = os.path.join(STORAGE_PATH, 'repos', project_name or 'unknown', filename)
    if not os.path.exists(filepath):
        # Backward compatibility
        old_filepath = os.path.join(STORAGE_PATH, filename)
        if os.path.exists(old_filepath):
            return send_file(old_filepath, as_attachment=True, download_name=filename)
        return jsonify({'error': 'Arquivo não encontrado'}), 404

    return send_file(filepath, as_attachment=True, download_name=filename)

@app.route('/snapshot/<snapshot_id>', methods=['DELETE'])
def delete_snapshot(snapshot_id):
    """Remove snapshot"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.execute('SELECT filename, project_name FROM snapshots WHERE id = ?', (snapshot_id,))
    result = cursor.fetchone()

    if result:
        filename, project_name = result
        filepath = os.path.join(STORAGE_PATH, 'repos', project_name or 'unknown', filename)
        if os.path.exists(filepath):
            os.remove(filepath)
        else:
            # Backward compatibility
            old_filepath = os.path.join(STORAGE_PATH, filename)
            if os.path.exists(old_filepath):
                os.remove(old_filepath)
        conn.execute('DELETE FROM snapshots WHERE id = ?', (snapshot_id,))
        conn.commit()

    conn.close()
    return jsonify({'deleted': snapshot_id})

@app.route('/snapshot/<snapshot_id>/verify', methods=['GET'])
def verify_snapshot(snapshot_id):
    """Verifica integridade do snapshot recalculando hash"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.execute('SELECT filename, hash, project_name FROM snapshots WHERE id = ?', (snapshot_id,))
    result = cursor.fetchone()
    conn.close()

    if not result:
        return "NOT FOUND", 404

    filename, stored_hash, project_name = result
    filepath = os.path.join(STORAGE_PATH, 'repos', project_name or 'unknown', filename)
    if not os.path.exists(filepath):
        # Backward compatibility
        old_filepath = os.path.join(STORAGE_PATH, filename)
        if os.path.exists(old_filepath):
            filepath = old_filepath
        else:
            return "CORRUPTED\nFile missing", 200

    # Recalcula hash
    calculated_hash = hashlib.md5(open(filepath, 'rb').read()).hexdigest()

    if calculated_hash == stored_hash:
        return "OK"
    else:
        return "CORRUPTED"
@app.route('/', methods=['GET'])
def index():
    """Página de texto puro com snapshots organizados por projeto"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.execute("""
        SELECT project_name, id, filename, size, created_at, notes
        FROM snapshots
        ORDER BY project_name, created_at DESC
    """)

    projects = {}

    for project, sid, filename, size, created_at, notes in cursor.fetchall():
        project = project or "sem-nome"
        projects.setdefault(project, []).append({
            'id': sid,
            'filename': filename,
            'size': size,
            'created_at': created_at,
            'notes': notes
        })

    conn.close()

    response = "Clurg Remote - Index de Backups\n\n"
    for project, snaps in projects.items():
        response += f"Project: {project}\n"
        for snap in snaps:
            response += f"  - {snap['filename']} ({snap['size']} bytes) {snap['created_at']} /snapshot/{snap['id']}\n"
            if snap['notes']:
                response += f"    Notes: {snap['notes']}\n"
        response += "\n"

    return Response(response, mimetype='text/plain')

@app.route('/project/<project_name>', methods=['GET'])
def project_view(project_name):
    """Lista snapshots de um projeto específico com ordenação opcional"""
    order = request.args.get('order', 'desc')
    if order == 'size':
        order_by = 'size DESC'
    else:  # desc or default
        order_by = 'created_at DESC'

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.execute(f"""
        SELECT id, filename, size, created_at, notes
        FROM snapshots
        WHERE project_name = ?
        ORDER BY {order_by}
    """, (project_name,))

    snapshots = cursor.fetchall()
    conn.close()

    response = f"Clurg Remote - Project: {project_name}\n\n"
    if not snapshots:
        response += "No snapshots found for this project.\n"
    else:
        for sid, filename, size, created_at, notes in snapshots:
            response += f"- {filename} ({size} bytes) {created_at} /snapshot/{sid}\n"
            if notes:
                response += f"  Notes: {notes}\n"
        response += "\n"

    return Response(response, mimetype='text/plain')

if __name__ == '__main__':
    # Cria diretórios
    os.makedirs(STORAGE_PATH, exist_ok=True)
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    
    # Inicializa DB
    init_db()
    
    print(f"🚀 Clurg Server iniciando...")
    print(f"📁 Storage: {STORAGE_PATH}")
    print(f"🗄️  Database: {DB_PATH}")
    print(f"🌐 Endpoint: http://localhost:{config['server']['port']}")
    
    app.run(
        host=config['server']['host'],
        port=config['server']['port'],
        debug=config['server']['debug']
    )

    ├── app │ ├── mobile_client.py │ ├── server.py │ ├── templates │ │ └── index.html │ └── utils.py ├── config.toml ├── db │ └── clurg.db ├── README.md ├── requirements.txt ├── scripts │ ├── deploy_mobile.sh │ └── tunnel.sh ├── storage │ └── repos └── todo.md